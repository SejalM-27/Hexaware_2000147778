package main;

import model.*;

import java.sql.Date;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        // Initialize the database connection
        DatabaseManager.initializeDatabase();

        // Create instances of objects for interaction
        Scanner scanner = new Scanner(System.in);

        try {
            // Start main loop for user interaction
            while (true) {
                System.out.println("Welcome to the Student Information System");
                System.out.println("1. Add a student");
                System.out.println("2. View all students");
                System.out.println("3. Enroll a student in a course");
                System.out.println("4. View students enrolled in a course");
                System.out.println("5. Exit");
                System.out.print("Enter your choice: ");

                int choice = scanner.nextInt();
                scanner.nextLine();  // Consume newline left by nextInt()

                switch (choice) {
                    case 1:
                        // Add a new student
                        addStudent(scanner);
                        break;
                    case 2:
                        // View all students
                        viewAllStudents();
                        break;
                    case 3:
                        // Enroll a student in a course
                        enrollStudentInCourse(scanner);
                        break;
                    case 4:
                        // View students enrolled in a specific course
                        viewStudentsInCourse(scanner);
                        break;
                    case 5:
                        // Exit the program
                        System.out.println("Exiting the system...");
                        scanner.close();
                        return;
                    default:
                        System.out.println("Invalid choice, please try again.");
                        break;
                }
            }
        } catch (Exception e) {
            System.err.println("An error occurred: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Method to add a student to the database
    public static void addStudent(Scanner scanner) {
        try {
            System.out.println("Enter student details:");
            System.out.print("Student ID: ");
            int studentId = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            System.out.print("First Name: ");
            String firstName = scanner.nextLine();
            System.out.print("Last Name: ");
            String lastName = scanner.nextLine();
            System.out.print("Date of Birth (YYYY-MM-DD): ");
            String dateOfBirth = scanner.nextLine();
            System.out.print("Email: ");
            String email = scanner.nextLine();
            System.out.print("Phone Number: ");
            String phoneNumber = scanner.nextLine();

            Student student = new Student(studentId, firstName, lastName, Date.valueOf(dateOfBirth), email, phoneNumber);
            DatabaseManager.insertStudent(student);  // Add student to the database
            System.out.println("Student added successfully.");
        } catch (Exception e) {
            System.err.println("Error adding student: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Method to view all students in the system
    public static void viewAllStudents() {
        try {
            List<Student> students = DatabaseManager.getAllStudents();
            if (students.isEmpty()) {
                System.out.println("No students found.");
            } else {
                System.out.println("List of all students:");
                for (Student student : students) {
                    System.out.println(student);
                }
            }
        } catch (Exception e) {
            System.err.println("Error retrieving students: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Method to enroll a student in a course
    public static void enrollStudentInCourse(Scanner scanner) {
        try {
            System.out.print("Enter student ID to enroll: ");
            int studentId = scanner.nextInt();
            System.out.print("Enter course ID to enroll in: ");
            int courseId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            // Fetch the student and course from the database to validate their existence
            Student student = DatabaseManager.getStudentById(studentId);
            if (student == null) {
                System.out.println("Student with ID " + studentId + " does not exist.");
                return;
            }

            Course course = DatabaseManager.getCourseById(courseId);
            if (course == null) {
                System.out.println("Course with ID " + courseId + " does not exist.");
                return;
            }

            // Proceed with enrollment if student and course exist
            System.out.print("Enter enrollment date (YYYY-MM-DD): ");
            String enrollmentDate = scanner.nextLine();

            Enrollment enrollment = new Enrollment(student, course, Date.valueOf(enrollmentDate));
            DatabaseManager.insertEnrollment(enrollment);  // Enroll student in the course
            System.out.println("Student enrolled in the course successfully.");
        } catch (Exception e) {
            System.err.println("Error enrolling student: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Method to view students enrolled in a course
    public static void viewStudentsInCourse(Scanner scanner) {
        try {
            System.out.print("Enter course ID to view enrolled students: ");
            int courseId = scanner.nextInt();

            String condition = "course_id = " + courseId;
            List<Student> students = DatabaseManager.getStudentsByCondition(condition);
            if (students.isEmpty()) {
                System.out.println("No students found for this course.");
            } else {
                System.out.println("Students enrolled in the course:");
                for (Student student : students) {
                    System.out.println(student);
                }
            }
        } catch (Exception e) {
            System.err.println("Error retrieving students for the course: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
