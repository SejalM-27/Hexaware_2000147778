package model;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Student {
    private int studentId;
    private String firstName;
    private String lastName;
    private Date dateOfBirth;
    private String email;
    private String phoneNumber;
    private List<Course> enrolledCourses = new ArrayList<>();

    public Student(int studentId, String firstName, String lastName, Date dateOfBirth, String email, String phoneNumber) {
        this.studentId = studentId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.dateOfBirth = dateOfBirth;
        this.email = email;
        this.phoneNumber = phoneNumber;
    }

    public Student(int studentId) {
        this.studentId = studentId;
    }

    public int getStudentId() {
        return studentId;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public java.sql.Date getDateOfBirth() {
        return new java.sql.Date(dateOfBirth.getTime());
    }

    public String getEmail() {
        return email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public List<Course> getEnrolledCourses() {
        return enrolledCourses;
    }

    public void enrollInCourse(Course course) throws DuplicateEnrollmentException {
        if (enrolledCourses.contains(course)) {
            throw new DuplicateEnrollmentException("Student is already enrolled in the course: " + course.getCourseName());
        }
        enrolledCourses.add(course);
        System.out.println(firstName + " " + lastName + " has been enrolled in " + course.getCourseName());
    }

    public void displayStudentInfo() {
        System.out.println("Student ID: " + studentId);
        System.out.println("Name: " + firstName + " " + lastName);
        System.out.println("Date of Birth: " + dateOfBirth);
        System.out.println("Email: " + email);
        System.out.println("Phone Number: " + phoneNumber);
    }

    public void makePayment(double amount, Date paymentDate) {
        try {
            String query = "INSERT INTO payments (student_id, amount, payment_date) VALUES (?, ?, ?)";
            PreparedStatement statement = DatabaseManager.getConnection().prepareStatement(query);
            statement.setInt(1, this.studentId);
            statement.setDouble(2, amount);
            statement.setDate(3, new java.sql.Date(paymentDate.getTime()));
            statement.executeUpdate();
            System.out.println("Payment made successfully for student ID " + this.studentId);
        } catch (SQLException e) {
            System.err.println("Error making payment: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    public String toString() {
        return "Student{" +
                "studentId=" + studentId +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", dateOfBirth=" + dateOfBirth +
                ", email='" + email + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", enrolledCourses=" + enrolledCourses +
                '}';
    }
}