package model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SIS {
    private List<Student> students = new ArrayList<>();
    private List<Course> courses = new ArrayList<>();
    private List<Teacher> teachers = new ArrayList<>();
    private List<Enrollment> enrollments = new ArrayList<>();
    private List<Payment> payments = new ArrayList<>();

    public SIS() {}

    public void enrollStudentInCourse(Student student, Course course) throws DuplicateEnrollmentException, InvalidEnrollmentDataException {
        for (Enrollment enrollment : enrollments) {
            if (enrollment.getStudent().getStudentId() == student.getStudentId() && enrollment.getCourse().getCourseId() == course.getCourseId()) {
                throw new DuplicateEnrollmentException("Student " + student.getFirstName() + " is already enrolled in " + course.getCourseName());
            }
        }
        if (student == null || course == null) {
            throw new InvalidEnrollmentDataException("Invalid data: Student or Course cannot be null.");
        }
        Enrollment newEnrollment = new Enrollment(student, course, new java.sql.Date(new Date().getTime()));
        enrollments.add(newEnrollment);
        course.getEnrollments().add(newEnrollment);
        System.out.println(student.getFirstName() + " has been successfully enrolled in " + course.getCourseName());
    }

    public void assignTeacherToCourse(Teacher teacher, Course course) throws TeacherNotFoundException {
        if (teacher == null) {
            throw new TeacherNotFoundException("Teacher not found.");
        }
        course.assignTeacher(teacher);
        teacher.getAssignedCourses().add(course);
        System.out.println("Teacher " + teacher.getFirstName() + " has been assigned to course " + course.getCourseName());
    }

    public void recordPayment(Student student, double amount, Date paymentDate) throws PaymentValidationException {
        if (amount <= 0) {
            throw new PaymentValidationException("Invalid payment amount: Amount must be greater than zero.");
        }
        Payment payment = new Payment(payments.size() + 1, student.getStudentId(), amount, paymentDate);
        payments.add(payment);
        student.makePayment(amount, paymentDate);
        System.out.println("Payment of " + amount + " has been recorded for student " + student.getFirstName());
    }

    public void generateEnrollmentReport(Course course) {
        System.out.println("Enrollment Report for course: " + course.getCourseName());
        boolean hasEnrollments = false;
        for (Enrollment enrollment : enrollments) {
            if (enrollment.getCourse().getCourseId() == course.getCourseId()) {
                hasEnrollments = true;
                System.out.println("Student: " + enrollment.getStudent().getFirstName() + " " + enrollment.getStudent().getLastName() + ", enrolled on: " + enrollment.getEnrollmentDate());
            }
        }
        if (!hasEnrollments) {
            System.out.println("No students are enrolled in this course.");
        }
    }

    public void generatePaymentReport(Student student) {
        System.out.println("Payment Report for student: " + student.getFirstName() + " " + student.getLastName());
        boolean hasPayments = false;
        for (Payment payment : payments) {
            if (payment.getStudentId() == student.getStudentId()) {
                hasPayments = true;
                System.out.println("Payment Amount: " + payment.getPaymentAmount() + " on " + payment.getPaymentDate());
            }
        }
        if (!hasPayments) {
            System.out.println("No payments found for this student.");
        }
    }

    public void calculateCourseStatistics(Course course) {
        int enrollmentCount = 0;
        double totalPayments = 0;
        for (Enrollment enrollment : enrollments) {
            if (enrollment.getCourse().getCourseId() == course.getCourseId()) {
                enrollmentCount++;
            }
        }
        for (Payment payment : payments) {
            for (Enrollment enrollment : enrollments) {
                if (enrollment.getStudent().getStudentId() == payment.getStudentId() && enrollment.getCourse().getCourseId() == course.getCourseId()) {
                    totalPayments += payment.getPaymentAmount();
                }
            }
        }
        System.out.println("Course Statistics for: " + course.getCourseName());
        System.out.println("Total Enrollments: " + enrollmentCount);
        System.out.println("Total Payments: " + totalPayments);
    }

    public void addEnrollment(Student student, Course course, Date enrollmentDate) throws DuplicateEnrollmentException, InvalidEnrollmentDataException {
        for (Enrollment enrollment : enrollments) {
            if (enrollment.getStudent().getStudentId() == student.getStudentId() && enrollment.getCourse().getCourseId() == course.getCourseId()) {
                throw new DuplicateEnrollmentException("Student " + student.getFirstName() + " is already enrolled in this course.");
            }
        }
        Enrollment newEnrollment = new Enrollment(student, course, new java.sql.Date(enrollmentDate.getTime()));
        enrollments.add(newEnrollment);
        student.enrollInCourse(course);
        course.getEnrollments().add(newEnrollment);
        System.out.println("Enrollment added for student " + student.getFirstName() + " in course " + course.getCourseName());
    }

    public void assignCourseToTeacher(Course course, Teacher teacher) throws TeacherNotFoundException {
        if (teacher == null) {
            throw new TeacherNotFoundException("Teacher not found.");
        }
        course.assignTeacher(teacher);
        teacher.getAssignedCourses().add(course);
        System.out.println("Course " + course.getCourseName() + " has been assigned to teacher " + teacher.getFirstName());
    }

    public void addPayment(Student student, double amount, Date paymentDate) throws PaymentValidationException {
        if (amount <= 0) {
            throw new PaymentValidationException("Payment amount must be greater than zero.");
        }
        Payment payment = new Payment(payments.size() + 1, student.getStudentId(), amount, paymentDate);
        payments.add(payment);
        student.makePayment(amount, paymentDate);
        System.out.println("Payment of " + amount + " has been recorded for student " + student.getFirstName());
    }

    public List<Enrollment> getEnrollmentsForStudent(Student student) {
        List<Enrollment> studentEnrollments = new ArrayList<>();
        for (Enrollment enrollment : enrollments) {
            if (enrollment.getStudent().getStudentId() == student.getStudentId()) {
                studentEnrollments.add(enrollment);
            }
        }
        return studentEnrollments;
    }

    public List<Course> getCoursesForTeacher(Teacher teacher) {
        return teacher.getAssignedCourses();
    }

    public List<Student> getStudents() {
        return students;
    }

    public List<Course> getCourses() {
        return courses;
    }

    public List<Teacher> getTeachers() {
        return teachers;
    }

    public List<Enrollment> getEnrollments() {
        return enrollments;
    }

    public List<Payment> getPayments() {
        return payments;
    }
}