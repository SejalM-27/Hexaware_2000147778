package model;

// Custom Exception Definitions
public class InvalidEnrollmentDataException extends Exception {
    public InvalidEnrollmentDataException(String message) {
        super(message);
    }
}
