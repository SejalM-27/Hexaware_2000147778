package Test;

import model.*;

import java.util.Date;

public class SISDriver {
    public static void main(String[] args) {
        SIS sis = new SIS();

        try {
            Student student1 = new Student(1, "John", "Doe", new Date(), "johndoe@example.com", "123-456-7890");
            Student student2 = new Student(2, "Jane", "Smith", new Date(), "janesmith@example.com", "456-789-0123");
            Teacher teacher1 = new Teacher(1, "Dr. Alice", "Johnson", "alice.johnson@school.com");
            Teacher teacher2 = new Teacher(2, "Dr. Bob", "Williams", "bob.williams@school.com");
            Course course1 = new Course(101, "Math 101");
            Course course2 = new Course(102, "History 101");

            sis.getStudents().add(student1);
            sis.getStudents().add(student2);
            sis.getTeachers().add(teacher1);
            sis.getTeachers().add(teacher2);
            sis.getCourses().add(course1);
            sis.getCourses().add(course2);

            sis.assignTeacherToCourse(teacher1, course1);
            sis.assignTeacherToCourse(teacher2, course2);

            sis.enrollStudentInCourse(student1, course1);
            sis.enrollStudentInCourse(student2, course2);

            sis.recordPayment(student1, 500, new Date());
            sis.recordPayment(student2, 600, new Date());

            sis.generateEnrollmentReport(course1);
            sis.generateEnrollmentReport(course2);
            sis.generatePaymentReport(student1);

        } catch (InvalidCourseDataException | TeacherNotFoundException | DuplicateEnrollmentException | InvalidEnrollmentDataException | PaymentValidationException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}