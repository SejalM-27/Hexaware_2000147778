
package main;

import dao.CrimeAnalysisServiceImpl;
import dao.ICrimeAnalysisService;
import entity.Incident; // Explicitly import the correct Incident class
import entity.Point;
import exception.IncidentNumberNotFoundException;

import java.util.Date;
import java.util.Scanner;

public class Mainmodule {
    public static void main(String[] args) {
        ICrimeAnalysisService service = new CrimeAnalysisServiceImpl();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nCrime Analysis and Reporting System");
            System.out.println("1. Create Incident");
            System.out.println("2. Update Incident Status");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            try {
                switch (choice) {
                    case 1:

                        // Prompt the user for input
                        System.out.print("Enter Incident ID : ");
                        int incidentID = scanner.nextInt();
                        scanner.nextLine(); // Consume newline

                        System.out.print("Enter Incident Type (Robbery,Theft,Homicide,Murder): ");
                        String incidentType = scanner.nextLine();

                        System.out.print("Enter Incident Date (yyyy-mm-dd): ");
                        String dateInput = scanner.nextLine();
                        Date incidentDate = java.sql.Date.valueOf(dateInput);

                        System.out.print("Enter location: ");
                        String location = scanner.nextLine(); // Consume newline

                        System.out.print("Enter Description : ");
                        String description = scanner.nextLine();

                        System.out.print("Enter Status (Open,Close,Under Investigation): ");
                        String status = scanner.nextLine();

                        System.out.print("Enter Victim ID (integer): ");
                        int victimID = scanner.nextInt();

                        System.out.print("Enter Suspect ID (integer): ");
                        int suspectID = scanner.nextInt();

                        System.out.print("Enter Officer ID (integer): ");
                        int officerID = scanner.nextInt();

                        // Create the Incident object
                        Incident incident = new Incident(incidentID, incidentType, incidentDate, location, description, status, victimID, suspectID, officerID);
                        if (service.createIncident(incident)) {
                            System.out.println("Incident created successfully.");
                        } else {
                            System.out.println("Failed to create incident.");
                        }
                        break;
                    case 2:
                        System.out.print("Enter Incident ID: ");
                        int id = scanner.nextInt();
                        System.out.print("Enter new status: ");
                        String stat = scanner.next();
                        if (service.updateIncidentStatus(stat, id)) {
                            System.out.println("Status updated successfully.");
                        } else {
                            throw new IncidentNumberNotFoundException("No such incident recorded with Id -"+id);
                        }
                        break;
                    case 3:
                        System.out.println("Exiting...");
                        scanner.close();
                        return;
                    default:
                        System.out.println("Invalid choice.");
                }
            } catch (IncidentNumberNotFoundException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }
}