
package dao;

import util.DBConnUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import entity.Incident;
import entity.Report;


public class CrimeAnalysisServiceImpl implements ICrimeAnalysisService {
    private static Connection connection;

    public CrimeAnalysisServiceImpl() {
        // Pass the required argument to the getConnection() method
        connection = DBConnUtil.getConnection("db.properties");
    }


    @Override
    public boolean createIncident(Incident incident) {
        String sql = "INSERT INTO Incidents1 (IncidentID, IncidentType, IncidentDate, Location, Description, Status, VictimID, SuspectID, OfficerID) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, incident.getIncidentID());
            ps.setString(2, incident.getIncidentType());
            ps.setDate(3, new java.sql.Date(incident.getIncidentDate().getTime()));
            ps.setString(4, incident.getLocation()); // Now passing the location as a string
            ps.setString(5, incident.getDescription());
            ps.setString(6, incident.getStatus());
            ps.setInt(7, incident.getVictimID());
            ps.setInt(8, incident.getSuspectID());
            ps.setInt(9, incident.getOfficerID());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }


    @Override

    public boolean updateIncidentStatus(String stat, int incidentID) {
        if (stat == null || stat.isEmpty()) {
            throw new IllegalArgumentException("Status cannot be null or empty.");
        }
        if (stat.length() > 50) { // Ensure status length matches database constraints
            throw new IllegalArgumentException("Status length exceeds limit.");
        }

        String updateSql = "UPDATE Incidents1 SET Status = ? WHERE IncidentID = ?";
        try (PreparedStatement updatePs = connection.prepareStatement(updateSql)) {
            updatePs.setString(1, stat);
            updatePs.setInt(2, incidentID);
            return updatePs.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }





    @Override
    public Collection<Incident> getIncidentsInDateRange(Date startDate, Date endDate) {
        Collection<Incident> incidents = new ArrayList<>();
        String sql = "SELECT * FROM Incidents WHERE IncidentDate BETWEEN ? AND ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setDate(1, new java.sql.Date(startDate.getTime()));
            ps.setDate(2, new java.sql.Date(endDate.getTime()));
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Incident incident = new Incident(rs.getInt("IncidentID"), rs.getString("IncidentType"),
                        rs.getDate("IncidentDate"), rs.getString("Location"),
                        rs.getString("Description"), rs.getString("Status"), rs.getInt("VictimID"),
                        rs.getInt("SuspectID"), rs.getInt("OfficerID"));
                incidents.add(incident);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return incidents;
    }

    @Override
    public Collection<Incident> searchIncidents(String incidentType) {
        Collection<Incident> incidents = new ArrayList<>();
        String sql = "SELECT * FROM Incidents WHERE IncidentType = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, incidentType);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Incident incident = new Incident(rs.getInt("IncidentID"), rs.getString("IncidentType"),
                        rs.getDate("IncidentDate"), rs.getString("location"),
                        rs.getString("Description"), rs.getString("Status"), rs.getInt("VictimID"),
                        rs.getInt("SuspectID"), rs.getInt("OfficerID"));
                incidents.add(incident);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return incidents;
    }

    @Override
    public Report generateIncidentReport(Incident incident) {
        // Simplified report generation
        return new Report(1, incident.getIncidentID(), incident.getOfficerID(), new Date(), "Report for " + incident.getIncidentType(), "Draft");
    }
}