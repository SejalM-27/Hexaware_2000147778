
package dao;

import entity.Report;
import entity.Incident;

import java.util.Collection;
import java.util.Date;

public interface ICrimeAnalysisService {
    boolean createIncident(Incident incident);
    boolean updateIncidentStatus(String status, int incidentID);
    Collection<Incident> getIncidentsInDateRange(Date startDate, Date endDate);
    Collection<Incident> searchIncidents(String incidentType);
    Report generateIncidentReport(Incident incident);
}